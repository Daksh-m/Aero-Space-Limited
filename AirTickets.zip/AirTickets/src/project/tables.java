
package project;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author daksh
 */
public class tables {
    public static void main(String[] args)
    {
        Connection con=null;
        Statement st=null;
        try{
con=ConnectionProvider.getcon();
st=con.createStatement();
st.executeUpdate("create table userinfo(special_id int(9) ,name varchar(30),email varchar(50),Phoneno bigint(20),age int(12)"
        + ",password varchar(20),Request varchar(20),PRIMARY KEY (special_id))");
         st.executeUpdate("create table admininfo(name varchar(30),password varchar(20))");
          st.executeUpdate("create table timeinfo(Pfrom varchar(30),Pto varchar(20),Ftime varchar(30))");
           st.executeUpdate("create table priceinfo(ftype varchar(30),travellers bigint(20),class varchar(30),airline varchar(30)"
                   + ",price bigint(20))");
    //       st.executeUpdate("create table allinfo(flight varchar(30),dfrom varchar(20),destination varchar(20),depart varchar(20)"
      //             + ",retun varchar(30),travellers varchar(30),class varchar(30),airlines varchar(30),price varchar(30),time varchar(30)"
        //           + ",payment varchar(30),billno int(9) AUTO_INCREMENT PRIMARY KEY,FOREIGN KEY(billno) REFERENCES userinfo(special_id)))");
           JOptionPane.showMessageDialog(null,"Table created Successfully");
        }
        catch(Exception e)
                {
                    JOptionPane.showMessageDialog(null,e);
                }
        
        finally{
            
           try{
               
               con.close();
               st.close();
               }            
        
        catch(Exception e)
                {
                   
                } 
        }
        
        
    }
            }
